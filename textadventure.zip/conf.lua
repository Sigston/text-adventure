function love.conf(t)
    t.window.title = "Text Adventure Prototype"
    t.window.width = 1200
    t.window.height = 800
    t.window.resizable = true
    t.console = false
end