function love.conf(t)
    t.window.title = "Breakout"
    t.window.width = 1200
    t.window.height = 800
    t.window.resizable = true
    t.console = false
end