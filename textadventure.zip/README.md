# Text Adventure
Writing a text adventure engine (eventually mirroring TADS) in Lua.
