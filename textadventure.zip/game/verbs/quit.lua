local function report()
    return { }, true
end

return { report = report }